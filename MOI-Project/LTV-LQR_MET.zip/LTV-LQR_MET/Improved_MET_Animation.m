function Improved_MET_Animation(t_f, yaw_vals, pitch_vals, roll_vals, L_vals, P)
    %% 3D ANIMATION SETUP    
    t = linspace(0, t_f, t_f / 0.001);
    
    % OPTIMIZATION 1: Skip frames for faster playback
    frame_skip = 25; % Only render every 5th frame
    t_indices = 1:frame_skip:length(t);
    t_display = t(t_indices);
    
    % Create rotation matrices for displayed frames only
    R = zeros(3, 3, length(t_indices));
    for i = 1:length(t_indices)
        idx = t_indices(i);
        % Create rotation matrix from Euler angles (yaw, pitch, roll)
        cy = cos(yaw_vals(idx));
        sy = sin(yaw_vals(idx));
        cp = cos(pitch_vals(idx));
        sp = sin(pitch_vals(idx));
        cr = cos(roll_vals(idx));
        sr = sin(roll_vals(idx));
        
        % ZYX rotation matrix
        R(:,:,i) = [cp*cy, cy*sp*sr-sy*cr, cy*sp*cr+sy*sr;
                    cp*sy, sy*sp*sr+cy*cr, sy*sp*cr-cy*sr;
                    -sp, cp*sr, cp*cr];
    end
    
    % Calculate positions for displayed frames only
    positions = zeros(3, 3, length(t_indices)); % [countermass; COM; payload] x [x,y,z] x time
    
    for i = 1:length(t_indices)
        idx = t_indices(i);
        % Calculate d (distance from countermass to COM)
        L = L_vals(idx);
        d = getCtoCOM_L(P.X(4), P.T.rho, P.P.m_p, P.C.m_c);
        
        % In the initial frame, the tether is along the x-axis
        baseline = [-d, 0, 0;
                    0, 0, 0;
                    L-d, 0, 0];
        
        % Rotate these positions according to the rotation matrix
        for j = 1:3  % For countermass, COM, payload
            positions(j,:,i) = (R(:,:,i) * baseline(j,:)')';
        end
    end
    
    %% OPTIMIZATION 2: Use animatedline for traces (much faster)
    figure(1);
    clf; % Clear figure for fresh start
    axis_limit = max(L_vals) * 1.2;
    
    % Initialize plot objects with better performance settings
    h_countermass = scatter3([], [], [], 200, 'filled', 'MarkerFaceColor', 'b');
    hold on;
    h_payload = scatter3([], [], [], 100, 'filled', 'MarkerFaceColor', 'r');
    h_com = scatter3(0, 0, 0, 150, 'filled', 'MarkerFaceColor', 'g');
    h_tether = plot3([0 0], [0 0], [0 0], 'k-', 'LineWidth', 2);
    
    % Use animatedline for much faster trace updates
    trace_length = 30;
    h_trace_c = animatedline('Color', [0, 0, 1, 0.5], 'LineWidth', 1, 'MaximumNumPoints', trace_length);
    h_trace_p = animatedline('Color', [1, 0, 0, 0.5], 'LineWidth', 1, 'MaximumNumPoints', trace_length);
    
    axis([-axis_limit, axis_limit, -axis_limit, axis_limit, -axis_limit, axis_limit]);
    grid on;
    box on;
    xlabel('X (m)');
    ylabel('Y (m)');
    zlabel('Z (m)');
    title('Momentum Exchange Tether 3D Animation (Optimized)');
    view(30, 20);
    
    % OPTIMIZATION 3: Reduce visual complexity
    % Comment out axis lines if not needed
    % line([-axis_limit, axis_limit], [0, 0], [0, 0], 'Color', 'k', 'LineStyle', ':');
    % line([0, 0], [-axis_limit, axis_limit], [0, 0], 'Color', 'k', 'LineStyle', ':');
    % line([0, 0], [0, 0], [-axis_limit, axis_limit], 'Color', 'k', 'LineStyle', ':');
    
    % Simplified info display
    % Define offset factor (adjust to fine-tune placement)
    offset = axis_limit * 0.95;

    % Place info text in bottom-left corner
    h_info = text(-offset, -offset, offset, '', ...
    'BackgroundColor', 'white', 'EdgeColor', 'black', 'FontSize', 10, ...
    'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left');
    
    legend([h_countermass, h_payload, h_com], {'Countermass', 'Payload', 'COM'}, ...
        'Location', 'northeast');
    
    % OPTIMIZATION 4: Pre-calculate timing
    % playback_speed = 0.1; % Much faster default
    % if length(t_display) > 1
    %     dt = t_display(2) - t_display(1);
    %     pause_time = dt * playback_speed;
    % else
    %     pause_time = 0.01;
    % end
    
    % OPTIMIZATION 5: Synchronized frame skip and drawnow
    % Every rendered frame gets a drawnow call for consistent display
    
    % Animation loop
    tic; % Start timing
    for i = 1:length(t_indices)
        % Update positions
        countermass_pos = squeeze(positions(1,:,i));
        payload_pos = squeeze(positions(3,:,i));
        
        % Update scatter plots
        set(h_countermass, 'XData', countermass_pos(1), 'YData', countermass_pos(2), 'ZData', countermass_pos(3));
        set(h_payload, 'XData', payload_pos(1), 'YData', payload_pos(2), 'ZData', payload_pos(3));
        
        % Update tether line
        set(h_tether, 'XData', [countermass_pos(1), payload_pos(1)], ...
                      'YData', [countermass_pos(2), payload_pos(2)], ...
                      'ZData', [countermass_pos(3), payload_pos(3)]);
        
        % Update traces using animatedline (much faster)
        addpoints(h_trace_c, countermass_pos(1), countermass_pos(2), countermass_pos(3));
        addpoints(h_trace_p, payload_pos(1), payload_pos(2), payload_pos(3));
        
        % Update info text less frequently
        if mod(i, 5) == 1
            info_str = sprintf('Time: %.2f s\nFrame: %d/%d\nSkipping: %d frames', t_display(i), i, length(t_indices), frame_skip);
            set(h_info, 'String', info_str);
        end
        
        % OPTIMIZATION 6: Synchronized drawnow - render every displayed frame
        drawnow;
        
        % Minimal pause (adjusted for frame skipping)
        % if pause_time > 0
        %     pause(pause_time);
        % end
    end
    
    elapsed_time = toc;
    fprintf('Animation completed in %.2f seconds\n', elapsed_time);
    fprintf('Average FPS: %.1f\n', length(t_indices)/elapsed_time);
end