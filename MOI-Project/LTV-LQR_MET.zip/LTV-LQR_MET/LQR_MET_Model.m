%% Assumptions
% u = [moment; moment; moment; L_dot]
% No max control input

clear;

%% INITIAL CONDITIONS

P = struct(...                            %%% Parameters
    'X', [0; 0; 0; 3], ...                % Current State [w_x, w_y, w_z, L]
    'XDesired', [0; pi; pi; 2], ...       % Desired State
    'theta', [0; 0; 0], ...               % Euler Angles (3-2-1)
    'd', 0, ...                           % Counter Mass to COM Distance (m)
    ...
    'C', struct( ...                      %% Counter Mass
              'm_c', 1e13, ...            % Mass of Counter Mass (kg)
              'R_c', 10 ...               % Radius of Counter Mass (m)
         ), ...
    'P', struct( ...                      %% Payload
              'm_p', 100, ...             % Mass of Payload (kg)
              'R_p', 0.1 ...              % Radius of Payload (m)
         ), ...
    'T', struct( ...                      %% Tether
              'rho', 7.85e12, ...         % Tether Density (kg/m^3)
              'R_t', 0.001 ...            % Radius of Tether (m)
         ), ...
    'control', struct( ...                %% LQR Control
              'Q', [1 0 0 0               % Weights
                    0 1 0 0
                    0 0 1 0
                    0 0 0 1], ...
              'R', 1 ...                  % Cost
         ) ...
);
P.T.m_t = P.T.rho * P.X(4); % Tether Mass;

% Store function handles in P
[f0_func, df_func] = precompute_dynamics();
P.f0_func = f0_func;
P.df_func = df_func;

%% SIMULATION

% Initial Iteration
tspan = linspace(0, 0.001, 10);

L_dot = 0;
A = compute_df(P, P.X, L_dot);
B = [1 0 0 0;
     0 1 0 0;
     0 0 1 0;
     0 0 0 1];

K = lqr(A, B, P.control.Q, P.control.R);
u = -K * (P.X - P.XDesired);

[t, X] = ode45(@(t, X) MET_dynamics(t, P.X, A, B, u), tspan, P.X);

X_SIM = X(end, :);
P.X = X(end, :)';
t_end = t(end);

% All Successive Iterations
tol = 0.00001;
while any(abs(P.X - P.XDesired) > tol)
    tspan = linspace(t_end, t_end + 0.001, 10);

    L_dot = u(4);
    A = compute_df(P, P.X, L_dot);

    K = lqr(A, B, P.control.Q, P.control.R);
    u = -K * (P.X - P.XDesired);

    % Simulates for discrete time interval
    [t, X] = ode45(@(t, X) MET_dynamics(t, P.X, A, B, u), tspan, P.X);

    X(end, :)
    
    % Stores Final Point
    X_SIM(end+1, :) = X(end, :);
    P.X = X(end, :)';
    t_end = t(end);
end

% Euler Angle Determination
tspan = linspace(0, 0.001, 10);
t_f = 0;
row = 1;
theta_SIM = [0, 0, 0];

while t_end > t_f
    % Simulates over a discrete time interval
    [t, theta] = ode45(@(t, theta) orientation(t, P.theta, X_SIM(row,1:3)'), tspan, P.theta);

    % Stores Final Point
    theta_SIM(end+1, :) = theta(end, :);
    P.theta = theta(end, :)';
    t_f = t(end);

    tspan = linspace(t_f, t_f + 0.001, 10);
    row = row + 1;
end

%% Animation
yaw_vals = theta_SIM(:, 1);
pitch_vals = theta_SIM(:, 2);
roll_vals = theta_SIM(:, 3);
L_vals = X_SIM(:, 4);

Improved_MET_Animation(t_f, yaw_vals, pitch_vals, roll_vals, L_vals, P);