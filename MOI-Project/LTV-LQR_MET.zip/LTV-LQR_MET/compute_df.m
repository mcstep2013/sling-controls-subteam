function df = compute_df(P, X, L_dot)
    % Use the precomputed function handle
    P.d = getCtoCOM_L(P.X(4), P.T.rho, P.P.m_p, P.C.m_c);
    df = P.df_func(P.C.R_c, P.P.R_p, P.T.R_t, P.d, X(1), X(2), X(3), X(4), ...
        P.C.m_c, P.P.m_p, P.T.rho, L_dot);
end