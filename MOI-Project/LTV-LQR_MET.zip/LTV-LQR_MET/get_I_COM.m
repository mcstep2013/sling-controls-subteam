% Calculates tensor matrix about COM
function [I_COM] = get_I_COM(rho, L, m_c, m_p, R_c, R_p, R_t)

    % Gets length from counter mass to COM
    d = getCtoCOM_L(L, rho, m_p, m_c);

    % Mass of tether
    m_t = rho * L;

    % Calculates tensor matrices accounting for Parallel Axis Theorem
    I_c = [(2/5) * m_c * R_c^2, 0, 0;
          0, (2/5) * m_c * R_c^2 + m_c * d^2, 0;
          0, 0, (2/5) * m_c * R_c^2 + m_c * d^2];

    I_p = [(2/5) * m_p * R_p^2, 0, 0;
          0, (2/5) * m_p * R_p^2 + m_p * (L-d)^2, 0;
          0, 0, (2/5) * m_p * R_p^2 + m_p * (L-d)^2];

    I_t = [(1/2) * m_t * R_t^2, 0, 0;
          0, (1/12) * m_t * L^2 + m_t * (L/2 - d)^2, 0;
          0, 0, (1/12) * m_t * L^2 + m_t * (L/2 - d)^2];

    I_tot = I_c + I_p + I_t;

    % Outputs MOI about each axis as vector
    I_COM = [I_tot(1), I_tot(5), I_tot(9)];
end