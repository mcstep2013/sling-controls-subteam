% Body to Euler Rate Matrix (thetadot = B^(-1)(theta)*w)   (3-2-1)
function B = bodyToEuler(theta)
    %theta1 = theta(1); % yaw
    theta2 = theta(2); % pitch
    theta3 = theta(3); % roll
    
    B = (1/cos(theta2)) * ...
        [0, sin(theta3), cos(theta3);
         0, cos(theta2)*cos(theta3), -cos(theta2)*sin(theta3);
         cos(theta2), sin(theta2)*sin(theta3), sin(theta2)*cos(theta3)];
end