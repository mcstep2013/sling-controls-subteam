function dx = MET_dynamics(~, X, A, B, u)
    dx = A*X + B*u;
end