function dtheta = orientation(~, theta, omega)
    % Euler angle derivatives (using B(theta) * omega)
    B = bodyToEuler(theta); % 3-2-1 Rotation
    dtheta = B * omega;
end