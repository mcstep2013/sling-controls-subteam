% Finds length from counter mass to COM
function [CtoCOM_L] = getCtoCOM_L(L, rho, m_p, m_c)
    CtoCOM_L = L * (1/2) * (rho*L + m_p) / (m_c + m_p + rho*L);
end