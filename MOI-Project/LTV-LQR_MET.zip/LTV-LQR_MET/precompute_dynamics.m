function [f0_func, df_func] = precompute_dynamics()
    syms m_c m_p rho R_c R_p R_t d w_x w_y w_z L I_x I_yz I_x_dot I_yz_dot L_dot
    
    % Moment of Inertia Equations
    I_x = (2/5)*m_c*R_c^2 + (2/5)*m_p*R_p^2 + (1/2)*rho*L*R_t^2;
    I_x_dot = 0;
    I_yz = m_c*R_c^2 + m_c*d^2 + m_p*R_p^2 + m_p*(L - d)^2 + (1/12)*rho*L*L^2 + rho*L*(L/2 - d)^2;
    I_yz_dot = diff(I_yz, L) * L_dot;
    
    % Assembles f0(x)
    w_x_dot = (1/I_x) * (-I_x_dot * w_x - w_y * w_z * (I_yz - I_yz));
    w_y_dot = (1/I_yz) * (-I_yz_dot * w_y - w_x * w_z * (I_x - I_yz));
    w_z_dot = (1/I_yz) * (-I_yz_dot * w_z - w_x * w_y * (I_yz - I_x));
    f0_L_dot = 0;
    
    f0 = [w_x_dot; w_y_dot; w_z_dot; f0_L_dot];
    
    % State Vector
    state = [w_x; w_y; w_z; L];
    
    % Jacobian
    df = jacobian(f0, state);
    
    % Convert to function handles
    f0_func = matlabFunction(f0, 'Vars', {R_c, R_p, R_t, d, w_x, w_y, w_z, L, m_c, m_p, rho, L_dot});
    df_func = matlabFunction(df, 'Vars', {R_c, R_p, R_t, d, w_x, w_y, w_z, L, m_c, m_p, rho, L_dot});
end